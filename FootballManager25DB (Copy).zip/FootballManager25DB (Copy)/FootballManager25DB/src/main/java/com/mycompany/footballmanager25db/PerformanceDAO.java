/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.footballmanager25db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * @author daniele
 */
public class PerformanceDAO {

    public void insertIfNotExists(String squadra, String competizione, String stagione, int punti, int golFatti, int golSubiti)
            throws ClassNotFoundException, SQLException {

        Class.forName("com.mysql.cj.jdbc.Driver");

        try (Connection connection = DriverManager.getConnection(
                "URL DATABASE", "NOME UTENTE", "PASSWORD")) {
            connection.setAutoCommit(false);

            try (
                    PreparedStatement stmtSquadra = connection.prepareStatement(
                            "INSERT IGNORE INTO Squadre (nome) VALUES (?)"); PreparedStatement stmtStagione = connection.prepareStatement(
                            "INSERT IGNORE INTO Stagioni (annata) VALUES (?)"); PreparedStatement stmtPartecipazione = connection.prepareStatement(
                            "INSERT IGNORE INTO Partecipazioni (squadra, competizione, stagione) VALUES (?, ?, ?)"); PreparedStatement stmtPerformance = connection.prepareStatement(
                            "INSERT IGNORE INTO Performance (squadra, stagione, punti, golFatti, golSubiti) VALUES (?, ?, ?, ?, ?)")) {
                stmtSquadra.setString(1, squadra);
                stmtSquadra.execute();

                stmtStagione.setString(1, stagione);
                stmtStagione.execute();

                stmtPartecipazione.setString(1, squadra);
                stmtPartecipazione.setString(2, competizione);
                stmtPartecipazione.setString(3, stagione);
                stmtPartecipazione.execute();

                stmtPerformance.setString(1, squadra);
                stmtPerformance.setString(2, stagione);
                stmtPerformance.setInt(3, punti);
                stmtPerformance.setInt(4, golFatti);
                stmtPerformance.setInt(5, golSubiti);
                stmtPerformance.execute();

                connection.commit();
            } catch (SQLException ex) {
                connection.rollback();
                throw ex;
            }
        }
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.footballmanager25db.googleApi;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author daniele
 */
public class SheetDataParser {

    public List<PerformanceEntry> parse(List<List<Object>> values, String competizione) {
        if (values == null || values.size() < 3) {
            return List.of();
        }
        List<String> stagioniColonne = new ArrayList<>();
        String lastStagione = "";

        for (Object cell : values.get(0)) {
            String stagione;
            if (cell != null) {
                stagione = cell.toString().trim();
            } else {
                stagione = "";
            }
            if (!stagione.isEmpty()) {
                lastStagione = stagione;
            }
            stagioniColonne.add(lastStagione);
        }
        List<String> intestazioni = new ArrayList<>();
        for (Object cell : values.get(1)) {
            if (cell != null) {
                intestazioni.add(cell.toString().trim());
            } else {
                intestazioni.add("");
            }
        }
        List<PerformanceEntry> risultati = new ArrayList<>();
        for (int row = 2; row < values.size(); row++) {
            List<Object> riga = values.get(row);
            String squadra = riga.get(0).toString().trim();
            for (int col = 1; col < riga.size(); col++) {
                if (col >= stagioniColonne.size()) {
                    continue;
                }
                String stagione = stagioniColonne.get(col);
                String tipoDato = intestazioni.get(col);
                String val = riga.get(col).toString().trim();
                if (val.equals("/") || !val.matches("-?\\d+")) {
                    continue;
                }
                PerformanceEntry entry = risultati.stream()
                        .filter(e -> e.getSquadra().equals(squadra) && e.getStagione().equals(stagione))
                        .findFirst()
                        .orElseGet(() -> {
                            PerformanceEntry nuovo = new PerformanceEntry(squadra, stagione, competizione);
                            risultati.add(nuovo);
                            return nuovo;
                        });
                switch (tipoDato) {
                    case "Punti" ->
                        entry.setPunti(Integer.parseInt(val));
                    case "Gol Fatti" ->
                        entry.setGolFatti(Integer.parseInt(val));
                    case "Gol Subiti" ->
                        entry.setGolSubiti(Integer.parseInt(val));
                }
            }
        }
        return risultati;
    }
}

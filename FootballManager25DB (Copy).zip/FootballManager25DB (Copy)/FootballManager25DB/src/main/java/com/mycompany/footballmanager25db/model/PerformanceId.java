/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.footballmanager25db.model;

import jakarta.persistence.Embeddable;

/**
 *
 * @author daniele
 */
@Embeddable
public class PerformanceId {

    private String squadra;
    private String stagione;

    public PerformanceId() {
    }

    public PerformanceId(String squadra, String stagione) {
        this.squadra = squadra;
        this.stagione = stagione;
    }

}

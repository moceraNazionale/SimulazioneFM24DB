/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.footballmanager25db.googleApi;

import com.google.api.services.sheets.v4.Sheets;
import com.google.api.services.sheets.v4.model.ValueRange;
import java.io.IOException;
import java.util.List;

/**
 *
 * @author daniele
 */
public class SheetDataFetcher {

    private final Sheets sheets;

    public SheetDataFetcher(Sheets sheets) {
        this.sheets = sheets;
    }

    public List<List<Object>> fetchSheetData(String spreadsheetId, String sheetName, String lastColumn) throws IOException {
        String range = sheetName + "!A1:" + lastColumn;
        ValueRange response = sheets.spreadsheets().values().get(spreadsheetId, range).execute();
        return response.getValues();
    }
}

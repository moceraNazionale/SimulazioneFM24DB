/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.footballmanager25db.model;

import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

/**
 *
 * @author daniele
 */
@Entity
@Table(name = "Partecipazioni")
public class Partecipazione {

    @EmbeddedId
    private PartecipazioneId id;

    public Partecipazione() {
    }

    public Partecipazione(PartecipazioneId id) {
        this.id = id;
    }

    public PartecipazioneId getId() {
        return id;
    }

    public void setId(PartecipazioneId id) {
        this.id = id;
    }

}

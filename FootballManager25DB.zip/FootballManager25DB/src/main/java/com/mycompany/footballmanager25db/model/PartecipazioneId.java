/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.footballmanager25db.model;

import jakarta.persistence.Embeddable;
import java.util.Objects;

/**
 *
 * @author daniele
 */
@Embeddable
public class PartecipazioneId {

    private String squadra;
    private String competizione;
    private String stagione;

    public PartecipazioneId() {
    }

    public PartecipazioneId(String squadra, String competizione, String stagione) {
        this.squadra = squadra;
        this.competizione = competizione;
        this.stagione = stagione;
    }

    public String getSquadra() {
        return squadra;
    }

    public void setSquadra(String squadra) {
        this.squadra = squadra;
    }

    public String getCompetizione() {
        return competizione;
    }

    public void setCompetizione(String competizione) {
        this.competizione = competizione;
    }

    public String getStagione() {
        return stagione;
    }

    public void setStagione(String stagione) {
        this.stagione = stagione;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 71 * hash + Objects.hashCode(this.squadra);
        hash = 71 * hash + Objects.hashCode(this.competizione);
        hash = 71 * hash + Objects.hashCode(this.stagione);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final PartecipazioneId other = (PartecipazioneId) obj;
        if (!Objects.equals(this.squadra, other.squadra)) {
            return false;
        }
        if (!Objects.equals(this.competizione, other.competizione)) {
            return false;
        }
        return Objects.equals(this.stagione, other.stagione);
    }

}

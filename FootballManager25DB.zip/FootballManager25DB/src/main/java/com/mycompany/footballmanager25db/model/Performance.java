/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.footballmanager25db.model;

import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

/**
 *
 * @author daniele
 */
@Entity
@Table(name = "Performance")
public class Performance {

    @EmbeddedId
    private PerformanceId id;
    private int punti;
    private int golFatti;
    private int golSubiti;

    public Performance() {
    }

    public Performance(PerformanceId id, int punti, int golFatti, int golSubiti) {
        this.id = id;
        this.punti = punti;
        this.golFatti = golFatti;
        this.golSubiti = golSubiti;
    }

    public PerformanceId getId() {
        return id;
    }

    public void setId(PerformanceId id) {
        this.id = id;
    }

    public int getPunti() {
        return punti;
    }

    public void setPunti(int punti) {
        this.punti = punti;
    }

    public int getGolFatti() {
        return golFatti;
    }

    public void setGolFatti(int golFatti) {
        this.golFatti = golFatti;
    }

    public int getGolSubiti() {
        return golSubiti;
    }

    public void setGolSubiti(int golSubiti) {
        this.golSubiti = golSubiti;
    }

}
